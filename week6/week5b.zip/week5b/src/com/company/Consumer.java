package com.company;

public class Consumer {
}
